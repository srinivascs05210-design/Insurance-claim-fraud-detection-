import { GoogleGenAI, Type } from "@google/genai";
import { ClaimData, AnalysisResult, ScoredClaim } from '../types';

const MODEL_NAME = "gemini-2.5-flash";

export async function analyzeClaims(sampleData: ClaimData[]): Promise<AnalysisResult> {
  // NOTE: This uses process.env.API_KEY as required.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const prompt = `
    You are an expert Senior Fraud Analyst for a major insurance company.
    Analyze the provided JSON dataset of insurance claims.
    
    Your tasks:
    1. Analyze each row for potential fraud indicators (e.g., round numbers, suspicious dates, high amounts, mismatching descriptions).
    2. Assign a 'riskScore' (0-100) to EACH row.
    3. Provide a short 'riskReason' for the score.
    4. Provide a high-level summary of the dataset.
    5. Suggest metrics that would be useful for a Power BI dashboard.
    
    Dataset Sample (JSON):
    ${JSON.stringify(sampleData)}
  `;

  // We define the schema to ensure we get structured data back that matches our app's needs.
  const response = await ai.models.generateContent({
    model: MODEL_NAME,
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          summary: { type: Type.STRING, description: "Overall analysis of the dataset patterns." },
          totalValue: { type: Type.NUMBER, description: "Total value of all claims in sample." },
          fraudProbability: { type: Type.NUMBER, description: "Overall probability (0-1) that this batch contains fraud." },
          keyInsights: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING },
            description: "3-5 bullet points of key findings." 
          },
          powerBIMetrics: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Suggested calculated columns or visuals for Power BI."
          },
          scoredClaims: {
            type: Type.ARRAY,
            description: "The original claims enriched with risk data. ORDER MUST MATCH INPUT.",
            items: {
              type: Type.OBJECT,
              properties: {
                riskScore: { type: Type.NUMBER },
                riskReason: { type: Type.STRING },
                riskLevel: { type: Type.STRING, enum: ["Low", "Medium", "High", "Critical"] },
                // We will merge this with original data manually, but helpful if AI echoes an ID if present.
                // For simplicity, we assume the AI processes the array in order.
              }
            }
          }
        }
      }
    }
  });

  const resultText = response.text;
  if (!resultText) {
    throw new Error("No response from Gemini");
  }

  const parsedResult = JSON.parse(resultText);

  // Merge the AI risk assessment back with the original sample data
  // We assume the AI maintains order or we just map 1:1 for this demo
  const enrichedClaims: ScoredClaim[] = sampleData.map((claim, index) => {
    const aiScore = parsedResult.scoredClaims[index];
    return {
      ...claim,
      riskScore: aiScore?.riskScore || 0,
      riskReason: aiScore?.riskReason || "No anomaly detected",
      riskLevel: aiScore?.riskLevel || "Low"
    };
  });

  return {
    ...parsedResult,
    scoredClaims: enrichedClaims
  };
}