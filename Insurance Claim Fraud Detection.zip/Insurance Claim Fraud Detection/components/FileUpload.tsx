import React, { useRef, useState } from 'react';
import { CloudUpload, FileSpreadsheet, Zap } from 'lucide-react';

interface FileUploadProps {
  onFileSelect: (file: File) => void;
  onLoadSample?: () => void;
}

export const FileUpload: React.FC<FileUploadProps> = ({ onFileSelect, onLoadSample }) => {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.type === "text/csv" || file.name.endsWith('.csv')) {
        onFileSelect(file);
      } else {
        alert("Please upload a valid CSV file.");
      }
    }
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onFileSelect(e.target.files[0]);
    }
  };

  return (
    <div className="space-y-4">
      <div 
        onClick={handleClick}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`
          relative group cursor-pointer
          border-2 border-dashed rounded-2xl p-12 text-center transition-all duration-200 ease-in-out
          ${isDragging 
            ? 'border-blue-500 bg-blue-50/50 scale-[1.01]' 
            : 'border-slate-300 hover:border-blue-400 hover:bg-slate-50'
          }
        `}
      >
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleInputChange} 
          accept=".csv" 
          className="hidden" 
        />
        
        <div className="flex flex-col items-center space-y-4">
          <div className={`
            p-4 rounded-full transition-colors duration-200
            ${isDragging ? 'bg-blue-100 text-blue-600' : 'bg-slate-100 text-slate-500 group-hover:bg-blue-50 group-hover:text-blue-500'}
          `}>
            <CloudUpload className="w-10 h-10" />
          </div>
          
          <div className="space-y-1">
            <h3 className="text-lg font-semibold text-slate-900">
              Click to upload or drag and drop
            </h3>
            <p className="text-slate-500 text-sm">
              CSV files only (max 10MB)
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-400 bg-white px-3 py-1 rounded-full border border-slate-200 shadow-sm">
            <FileSpreadsheet className="w-3 h-3" />
            <span>Supported format: CSV</span>
          </div>
        </div>
      </div>

      {onLoadSample && (
        <div className="text-center">
          <div className="relative my-4">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t border-slate-200"></span>
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-slate-50 px-2 text-slate-400">Or</span>
            </div>
          </div>
          
          <button
            onClick={(e) => {
              e.stopPropagation();
              onLoadSample();
            }}
            className="inline-flex items-center space-x-2 text-sm font-medium text-blue-600 hover:text-blue-700 hover:underline"
          >
            <Zap className="w-4 h-4" />
            <span>Try with Sample Data</span>
          </button>
        </div>
      )}
    </div>
  );
};