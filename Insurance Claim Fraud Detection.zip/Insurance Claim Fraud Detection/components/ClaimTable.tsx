import React from 'react';
import { ScoredClaim } from '../types';
import { TriangleAlert, CircleCheck, Info } from 'lucide-react';

interface ClaimTableProps {
  data: ScoredClaim[];
}

export const ClaimTable: React.FC<ClaimTableProps> = ({ data }) => {
  if (!data || data.length === 0) return null;

  // Get headers excluding the risk metadata we added
  const excludedKeys = ['riskScore', 'riskReason', 'riskLevel'];
  const headers = Object.keys(data[0]).filter(k => !excludedKeys.includes(k)).slice(0, 5); // Show first 5 cols only for clean UI

  const getRiskBadge = (level: string, score: number) => {
    const styles = {
      Critical: "bg-red-100 text-red-700 border-red-200",
      High: "bg-orange-100 text-orange-700 border-orange-200",
      Medium: "bg-amber-100 text-amber-700 border-amber-200",
      Low: "bg-emerald-100 text-emerald-700 border-emerald-200",
    };
    
    const style = styles[level as keyof typeof styles] || styles.Low;
    const Icon = level === 'Critical' || level === 'High' ? TriangleAlert : (level === 'Medium' ? Info : CircleCheck);

    return (
      <div className={`flex items-center w-fit px-2.5 py-0.5 rounded-full text-xs font-medium border ${style}`}>
        <Icon className="w-3 h-3 mr-1.5" />
        {level} ({score})
      </div>
    );
  };

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-slate-200">
        <thead className="bg-slate-50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider w-24">
              Risk Score
            </th>
            <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider w-1/3">
              AI Analysis
            </th>
            {headers.map(header => (
              <th key={header} className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">
                {header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-slate-200">
          {data.map((row, rowIndex) => (
            <tr key={rowIndex} className="hover:bg-slate-50 transition-colors">
              <td className="px-6 py-4 whitespace-nowrap">
                {getRiskBadge(row.riskLevel, row.riskScore)}
              </td>
              <td className="px-6 py-4">
                 <p className="text-sm text-slate-600 line-clamp-2" title={row.riskReason}>
                    {row.riskReason}
                 </p>
              </td>
              {headers.map(header => (
                <td key={`${rowIndex}-${header}`} className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                  {String(row[header])}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};