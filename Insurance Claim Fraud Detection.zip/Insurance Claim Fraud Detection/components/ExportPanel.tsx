import React from 'react';
import { Download, FileJson, Table } from 'lucide-react';
import { ScoredClaim } from '../types';
import { exportToCSV } from '../utils/csvParser';

interface ExportPanelProps {
  processedData: ScoredClaim[];
  metrics: string[];
}

export const ExportPanel: React.FC<ExportPanelProps> = ({ processedData, metrics }) => {

  const handleDownloadCSV = () => {
    // Export the actual data with scores
    exportToCSV(processedData, `insurguard_analyzed_${new Date().toISOString().slice(0,10)}.csv`);
  };

  const handleDownloadMetrics = () => {
    // Create a simple CSV for the metrics suggestions
    const metricsData = metrics.map(m => ({ "Proposed Power BI Metric/Visual": m }));
    exportToCSV(metricsData, `power_bi_suggestions.csv`);
  };

  return (
    <div className="flex flex-wrap items-center gap-3">
      <button
        onClick={handleDownloadCSV}
        className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors shadow-sm"
      >
        <Table className="w-4 h-4" />
        <span>Download Processed Data</span>
      </button>
      
      <button
        onClick={handleDownloadMetrics}
        className="flex items-center space-x-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 px-4 py-2 rounded-lg text-sm font-medium transition-colors"
      >
        <FileJson className="w-4 h-4 text-slate-500" />
        <span>Get BI Suggestions</span>
      </button>
    </div>
  );
};