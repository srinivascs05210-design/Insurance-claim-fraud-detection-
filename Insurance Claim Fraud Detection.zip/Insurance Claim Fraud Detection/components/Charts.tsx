import React from 'react';
import { ScoredClaim } from '../types';

const COLORS = {
  Low: '#10b981', // emerald-500
  Medium: '#f59e0b', // amber-500
  High: '#f97316', // orange-500
  Critical: '#ef4444' // red-500
};

interface ChartProps {
  data: ScoredClaim[];
}

export const RiskChart: React.FC<ChartProps> = ({ data }) => {
  const counts = { Low: 0, Medium: 0, High: 0, Critical: 0 };
  data.forEach(d => {
    const level = d.riskLevel || 'Low';
    if (level in counts) {
      counts[level as keyof typeof counts]++;
    }
  });
  
  const total = data.length;
  
  // Calculate conic gradient segments
  let currentStart = 0;
  const gradientSegments = Object.entries(counts).map(([level, count]) => {
    if (count === 0) return null;
    const percentage = (count / total) * 100;
    const start = currentStart;
    currentStart += percentage;
    const color = COLORS[level as keyof typeof COLORS];
    return `${color} ${start}% ${currentStart}%`;
  }).filter(Boolean).join(', ');

  const background = total > 0 ? `conic-gradient(${gradientSegments})` : '#e2e8f0';

  return (
    <div className="w-full h-full flex flex-col items-center justify-center">
      <div className="relative w-48 h-48 rounded-full shadow-inner" style={{ background }}>
        <div className="absolute inset-0 m-8 bg-white rounded-full flex flex-col items-center justify-center shadow-sm">
          <span className="text-3xl font-bold text-slate-800">{total}</span>
          <span className="text-xs text-slate-400 uppercase font-medium">Claims</span>
        </div>
      </div>
      
      <div className="flex flex-wrap gap-3 justify-center mt-6">
        {Object.entries(counts).map(([level, count]) => (
          <div key={level} className="flex items-center text-xs font-medium text-slate-600">
            <span className="w-3 h-3 rounded-full mr-1.5 shadow-sm" style={{ backgroundColor: COLORS[level as keyof typeof COLORS] }}></span>
            {level} ({count})
          </div>
        ))}
      </div>
    </div>
  );
};

export const DistributionChart: React.FC<ChartProps> = ({ data }) => {
  // Show top 10 highest risk claims
  const topRisk = [...data].sort((a, b) => b.riskScore - a.riskScore).slice(0, 8);

  const getBarColor = (score: number) => {
    if (score > 80) return COLORS.Critical;
    if (score > 50) return COLORS.High;
    if (score > 20) return COLORS.Medium;
    return COLORS.Low;
  };

  if (data.length === 0) {
     return <div className="flex items-center justify-center h-full text-slate-400">No data available</div>;
  }

  return (
    <div className="w-full h-full overflow-y-auto pr-2 space-y-4">
      <div className="flex justify-between text-xs text-slate-400 border-b border-slate-100 pb-2">
        <span>Risk Reason / ID</span>
        <span>Risk Score</span>
      </div>
      {topRisk.map((item, index) => (
        <div key={index} className="group">
          <div className="flex justify-between text-sm mb-1">
            <div className="font-medium text-slate-700 truncate w-3/4 pr-2" title={item.riskReason}>
              {item.riskReason || `Claim #${index + 1}`}
            </div>
            <div className="font-bold text-slate-900 tabular-nums">{item.riskScore}</div>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
            <div 
              className="h-full rounded-full transition-all duration-1000 ease-out group-hover:opacity-90"
              style={{ 
                width: `${item.riskScore}%`,
                backgroundColor: getBarColor(item.riskScore)
              }}
            />
          </div>
          {/* Attempt to show amount if it exists */}
          <div className="flex justify-end mt-0.5">
             <span className="text-[10px] text-slate-400 font-mono">
                {Object.entries(item).find(([k]) => /amount|value|cost/i.test(k))?.[1]?.toString() || ''}
             </span>
          </div>
        </div>
      ))}
      {data.length > 8 && (
        <div className="text-center text-xs text-slate-400 pt-2">
          + {data.length - 8} more claims
        </div>
      )}
    </div>
  );
};
