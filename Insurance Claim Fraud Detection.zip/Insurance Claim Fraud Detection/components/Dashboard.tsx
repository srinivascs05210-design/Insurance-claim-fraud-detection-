import React from 'react';
import { AnalysisResult, ClaimData } from '../types';
import { ClaimTable } from './ClaimTable';
import { RiskChart, DistributionChart } from './Charts';
import { ExportPanel } from './ExportPanel';
import { Loader2, CircleCheck, CircleAlert, ChartBar } from 'lucide-react';

interface DashboardProps {
  fileName: string;
  rowCount: number;
  isAnalyzing: boolean;
  analysisResult: AnalysisResult | null;
  rawData: ClaimData[];
}

export const Dashboard: React.FC<DashboardProps> = ({ 
  fileName, 
  rowCount, 
  isAnalyzing, 
  analysisResult,
  rawData
}) => {
  if (isAnalyzing) {
    return (
      <div className="flex flex-col items-center justify-center h-96 space-y-6 animate-in fade-in duration-700">
        <div className="relative">
          <div className="absolute inset-0 bg-blue-500 blur-xl opacity-20 rounded-full"></div>
          <Loader2 className="w-16 h-16 text-blue-600 animate-spin relative z-10" />
        </div>
        <div className="text-center space-y-2">
          <h3 className="text-xl font-semibold text-slate-900">Analyzing Claim Patterns...</h3>
          <p className="text-slate-500 max-w-md">
            Gemini is reviewing {rowCount} records for anomalies, cross-referencing amounts, and calculating risk scores.
          </p>
        </div>
      </div>
    );
  }

  if (!analysisResult) return null;

  const highRiskCount = analysisResult.scoredClaims.filter(c => c.riskLevel === 'High' || c.riskLevel === 'Critical').length;
  const mediumRiskCount = analysisResult.scoredClaims.filter(c => c.riskLevel === 'Medium').length;

  return (
    <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
      {/* Top Summary Section */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* File Info */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200 col-span-1">
          <h3 className="text-sm font-medium text-slate-500 uppercase tracking-wider mb-4">Dataset</h3>
          <div className="flex items-center space-x-3 mb-2">
             <div className="p-2 bg-blue-50 rounded-lg">
                <ChartBar className="w-5 h-5 text-blue-600" />
             </div>
             <div className="overflow-hidden">
                <p className="text-base font-bold text-slate-900 truncate">{fileName}</p>
                <p className="text-xs text-slate-500">{rowCount.toLocaleString()} Total Records</p>
             </div>
          </div>
          <div className="mt-4 pt-4 border-t border-slate-100">
            <div className="flex justify-between items-center">
               <span className="text-xs text-slate-500">Processing Status</span>
               <span className="flex items-center text-xs font-medium text-emerald-600 bg-emerald-50 px-2 py-1 rounded-full">
                  <CircleCheck className="w-3 h-3 mr-1" /> Complete
               </span>
            </div>
          </div>
        </div>

        {/* AI Summary */}
        <div className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-xl p-6 shadow-lg text-white col-span-1 lg:col-span-2">
          <h3 className="text-sm font-medium text-slate-300 uppercase tracking-wider mb-2">AI Executive Summary</h3>
          <p className="text-slate-100 leading-relaxed text-sm">
            {analysisResult.summary}
          </p>
          <div className="mt-4 flex gap-2 flex-wrap">
             {analysisResult.keyInsights.slice(0, 2).map((insight, idx) => (
               <span key={idx} className="text-xs bg-white/10 px-3 py-1 rounded-full border border-white/20">
                 {insight}
               </span>
             ))}
          </div>
        </div>

        {/* Risk Meter */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200 col-span-1 flex flex-col justify-center items-center text-center">
           <h3 className="text-sm font-medium text-slate-500 uppercase tracking-wider mb-2">Fraud Exposure</h3>
           <div className="relative w-32 h-32 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90">
                 <circle cx="64" cy="64" r="56" stroke="currentColor" strokeWidth="12" fill="transparent" className="text-slate-100" />
                 <circle cx="64" cy="64" r="56" stroke="currentColor" strokeWidth="12" fill="transparent" 
                    strokeDasharray={351} 
                    strokeDashoffset={351 - (351 * analysisResult.fraudProbability)} 
                    className={`${analysisResult.fraudProbability > 0.5 ? 'text-red-500' : 'text-emerald-500'} transition-all duration-1000 ease-out`} 
                 />
              </svg>
              <div className="absolute flex flex-col items-center">
                 <span className="text-3xl font-bold text-slate-900">{(analysisResult.fraudProbability * 100).toFixed(0)}%</span>
                 <span className="text-xs text-slate-500">Probability</span>
              </div>
           </div>
           <p className="text-xs text-slate-500 mt-2">
             {highRiskCount} High Risk claims detected
           </p>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
         <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <h4 className="text-base font-semibold text-slate-900 mb-6 flex items-center">
               <CircleAlert className="w-4 h-4 mr-2 text-slate-400" />
               Risk Distribution
            </h4>
            <div className="h-64 w-full">
               <RiskChart data={analysisResult.scoredClaims} />
            </div>
         </div>
         <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <h4 className="text-base font-semibold text-slate-900 mb-6 flex items-center">
               <ChartBar className="w-4 h-4 mr-2 text-slate-400" />
               Claim Values vs Risk
            </h4>
            <div className="h-64 w-full">
               <DistributionChart data={analysisResult.scoredClaims} />
            </div>
         </div>
      </div>

      {/* Data Table & Export */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-lg font-bold text-slate-900">Analyzed Claims</h3>
            <p className="text-sm text-slate-500">Showing analyzed sample with AI-generated risk scores</p>
          </div>
          <ExportPanel 
             processedData={analysisResult.scoredClaims} 
             metrics={analysisResult.powerBIMetrics} 
          />
        </div>
        <ClaimTable data={analysisResult.scoredClaims} />
      </div>
    </div>
  );
};