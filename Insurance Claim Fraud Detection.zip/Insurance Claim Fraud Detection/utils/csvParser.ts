import { ClaimData } from '../types';

export function parseCSV(csvText: string): ClaimData[] {
  const lines = csvText.split(/\r\n|\n/);
  const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
  
  const result: ClaimData[] = [];

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    
    // Basic split handling quotes is tricky without a library, 
    // but for this demo we'll assume standard CSV or simple comma separation.
    // A robust regex for CSV: /,(?=(?:(?:[^"]*"){2})*[^"]*$)/
    const values = line.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/).map(val => {
      return val.trim().replace(/^"|"$/g, '');
    });

    if (values.length === headers.length) {
      const obj: ClaimData = {};
      headers.forEach((header, index) => {
        const value = values[index];
        // Try to convert to number if possible
        const numValue = parseFloat(value);
        obj[header] = !isNaN(numValue) && isFinite(numValue) ? numValue : value;
      });
      result.push(obj);
    }
  }
  
  return result;
}

export function exportToCSV(data: any[], filename: string) {
  if (!data || !data.length) return;
  
  const separator = ',';
  const keys = Object.keys(data[0]);
  
  const csvContent =
    keys.join(separator) +
    '\n' +
    data.map(row => {
      return keys.map(k => {
        let cell = row[k] === null || row[k] === undefined ? '' : row[k];
        cell = cell instanceof Date ? cell.toLocaleString() : cell.toString();
        if (cell.search(/("|,|\n)/g) >= 0) {
          cell = `"${cell.replace(/"/g, '""')}"`;
        }
        return cell;
      }).join(separator);
    }).join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}