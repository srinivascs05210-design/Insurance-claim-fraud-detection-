import React, { useState, useCallback } from 'react';
import { FileUpload } from './components/FileUpload';
import { Dashboard } from './components/Dashboard';
import { analyzeClaims } from './services/geminiService';
import { parseCSV } from './utils/csvParser';
import { ClaimData, AnalysisResult } from './types';
import { ShieldCheck, TriangleAlert, Activity, FileText } from 'lucide-react';

const SAMPLE_CSV = `ClaimID,PolicyHolder,PolicyType,IncidentDate,ClaimAmount,Description,Location
CLM001,John Smith,Auto,2023-10-15,1250.50,Fender bender in parking lot,Austin TX
CLM002,Sarah Connor,Home,2023-10-20,45000.00,Valuable electronics stolen during break-in,Los Angeles CA
CLM003,Mike Ross,Auto,2023-10-22,2500.00,Rear ended at stop light,New York NY
CLM004,Jane Doe,Health,2023-10-25,150.00,Routine checkup,Chicago IL
CLM005,Robert Chase,Auto,2023-11-01,9800.00,Hit a deer on highway,Denver CO
CLM006,Suspicious User,Home,2023-11-02,50000.00,Fire damage to detached garage,Miami FL
CLM007,John Smith,Auto,2023-11-03,1250.50,Fender bender in parking lot,Austin TX
CLM008,Emily Blunt,Travel,2023-11-05,2400.00,Lost luggage containing designer clothes,Paris France
CLM009,Walter White,Business,2023-11-10,75000.00,Inventory lost due to chemical spill,Albuquerque NM
CLM010,Jesse Pinkman,Auto,2023-11-12,420.00,Scratched paint,Albuquerque NM
CLM011,Saul Goodman,Liability,2023-11-15,10000.00,Slip and fall in office,Albuquerque NM
CLM012,Danny Ocean,Theft,2023-11-20,150000.00,Diamond necklace stolen from hotel safe,Las Vegas NV
CLM013,Rusty Ryan,Theft,2023-11-20,149999.00,Watch stolen from hotel room,Las Vegas NV`;

export default function App() {
  const [rawData, setRawData] = useState<ClaimData[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [fileName, setFileName] = useState<string>("");
  const [error, setError] = useState<string | null>(null);

  const handleFileUpload = useCallback(async (file: File) => {
    setError(null);
    setFileName(file.name);
    try {
      const text = await file.text();
      processData(text);
    } catch (err) {
      console.error(err);
      setError("Failed to parse CSV file.");
    }
  }, []);

  const handleLoadSample = useCallback(() => {
    setError(null);
    setFileName("Sample_Fraud_Dataset.csv");
    processData(SAMPLE_CSV);
  }, []);

  const processData = (csvText: string) => {
    const data = parseCSV(csvText);
      
    if (data.length === 0) {
      setError("The CSV file appears to be empty or invalid.");
      return;
    }

    // Basic validation: check if it looks like claim data (has at least 2 columns)
    if (Object.keys(data[0]).length < 2) {
      setError("The CSV file format is not recognized. Please ensure it has standard headers.");
      return;
    }

    setRawData(data);
    handleAnalysis(data);
  };

  const handleAnalysis = async (data: ClaimData[]) => {
    setIsAnalyzing(true);
    try {
      // We analyze a sample of up to 30 rows to avoid token limits in this demo context
      // In a real prod app, we might batch this or use the File API.
      const sampleSize = 30;
      const sampleData = data.slice(0, sampleSize);
      
      const result = await analyzeClaims(sampleData);
      
      // Merge AI results back into the full dataset logic for display
      setAnalysisResult(result);
    } catch (err) {
      console.error(err);
      setError("AI Analysis failed. Please check your API key and try again.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleReset = () => {
    setRawData([]);
    setAnalysisResult(null);
    setFileName("");
    setError(null);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-600 p-2 rounded-lg">
              <ShieldCheck className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900 tracking-tight">InsurGuard AI</h1>
              <p className="text-xs text-slate-500 font-medium">Fraud Detection Platform</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
             {rawData.length > 0 && (
                <button 
                  onClick={handleReset}
                  className="text-sm font-medium text-slate-600 hover:text-slate-900 transition-colors"
                >
                  Upload New File
                </button>
             )}
             <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center border border-blue-200">
                <span className="text-xs font-bold text-blue-700">JS</span>
             </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4 flex items-start space-x-3">
            <TriangleAlert className="h-5 w-5 text-red-500 mt-0.5" />
            <p className="text-sm text-red-700">{error}</p>
          </div>
        )}

        {rawData.length === 0 ? (
          <div className="max-w-2xl mx-auto mt-12">
             <div className="text-center mb-10">
                <h2 className="text-3xl font-bold text-slate-900 mb-4">
                  Intelligent Claims Analysis
                </h2>
                <p className="text-lg text-slate-600">
                  Upload your insurance claim CSV data. Our Gemini-powered engine will analyze patterns, detect potential fraud, and prepare actionable insights for Power BI.
                </p>
             </div>
             <FileUpload 
                onFileSelect={handleFileUpload} 
                onLoadSample={handleLoadSample}
             />
             
             <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
                <FeatureCard 
                  icon={<Activity className="h-6 w-6 text-blue-600" />}
                  title="Real-time Scoring"
                  description="Instant risk probability assessment for every claim row."
                />
                <FeatureCard 
                  icon={<ShieldCheck className="h-6 w-6 text-emerald-600" />}
                  title="Pattern Recognition"
                  description="AI detects subtle anomalies human analysts might miss."
                />
                <FeatureCard 
                  icon={<FileText className="h-6 w-6 text-purple-600" />}
                  title="Power BI Ready"
                  description="Export enriched datasets directly for your BI dashboards."
                />
             </div>
          </div>
        ) : (
          <Dashboard 
            fileName={fileName}
            rowCount={rawData.length}
            isAnalyzing={isAnalyzing}
            analysisResult={analysisResult}
            rawData={rawData}
          />
        )}
      </main>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
      <div className="mb-4 bg-slate-50 w-12 h-12 rounded-lg flex items-center justify-center">
        {icon}
      </div>
      <h3 className="font-semibold text-slate-900 mb-2">{title}</h3>
      <p className="text-sm text-slate-500 leading-relaxed">{description}</p>
    </div>
  );
}