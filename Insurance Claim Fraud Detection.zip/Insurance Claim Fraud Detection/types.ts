export interface ClaimData {
  [key: string]: string | number | boolean | null;
}

export interface ScoredClaim extends ClaimData {
  riskScore: number; // 0-100
  riskReason: string;
  riskLevel: 'Low' | 'Medium' | 'High' | 'Critical';
}

export interface AnalysisResult {
  summary: string;
  totalValue: number;
  fraudProbability: number; // Overall dataset risk
  keyInsights: string[];
  powerBIMetrics: string[];
  scoredClaims: ScoredClaim[];
}
